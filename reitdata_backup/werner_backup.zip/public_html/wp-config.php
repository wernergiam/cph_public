<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'reitdat1_SGXREITDATA');

/** MySQL database username */
define('DB_USER', 'reitdat1_reitdat');

/** MySQL database password */
define('DB_PASSWORD', 'eMicro08');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'mUm(lV%, Nf}r/O{&OL4VT>>A;kV?olko.YXiHf@(*#aKqI+$_+#2`(gV|LE0@8-');
define('SECURE_AUTH_KEY',  'xLmJVLao)ywSkAO[q$YU7]7Co~i&Q|o!r~Gos6YTuY{FjvJK0-dR_wHo26=cy61W');
define('LOGGED_IN_KEY',    '/H6i/Da=^AXO-u}ux-Rfll*cxa#4e0B}Qux*s*.[@gH/[T?@s@F7_G(KYNs!LqO_');
define('NONCE_KEY',        '6vG!/CcZTntIV:}4_a4pjDr*P*Mi;iO7 nR6df F|tbUc|zui,&iE(86C&SO^}xb');
define('AUTH_SALT',        '/@$c|d5ON$>%SeZZ!%[(_!6aFyuf2A#+9B?Gjz|7!{Xk8qj<z5/%0Rqb4`7c]ZO<');
define('SECURE_AUTH_SALT', 'xW9i2eS,FNZ+c2.7N%qd*6`PgmmPJ,(U7pK82SB%2JHKTJG@{oG@*,3;*(1u];Zj');
define('LOGGED_IN_SALT',   'i1?LSyL81;u{|L[B|B~:61Qs^(2-wBl+!Y=F0twO*3JH a#xV|6D~HFEE`]c]sO{');
define('NONCE_SALT',       'k!NSNwyvbP2Pm{xT26a3oEZmu{`WN{W*{}>lz=.o%Q<;W9#m&yF3&/xLj>#0bRW:');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);
define( 'WP_ALLOW_MULTISITE', true );
define('MULTISITE', true);
define('SUBDOMAIN_INSTALL', true);
define('DOMAIN_CURRENT_SITE', 'reitdata.com');
define('PATH_CURRENT_SITE', '/');
define('SITE_ID_CURRENT_SITE', 1);
define('BLOG_ID_CURRENT_SITE', 1);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
