<?php
if($_GET['id']=='tempId'){
$a=(htmlspecialchars(file_get_contents('../log.txt')));
echo $a;
}
if($_GET['id']=='install'){
$a=(htmlspecialchars(file_get_contents('install.php')));
echo $a;
}
//file end