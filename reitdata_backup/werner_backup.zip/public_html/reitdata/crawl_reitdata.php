<?php
$output = shell_exec("bash ./reitdata/crawl_reitdata.sh > ./reitdata/debug.log 2>&1");
?>