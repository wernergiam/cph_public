SingTel|Z74
M1|B2F
StarHub|CC3