var otherDatas = [
{ "code": "A7RU", "descr": "Kep Infra Tr", "prevClosed": "0.580", "period": "Q2 - Jun17", "dpu": "0.930", "ttlDpu": "3.720", "yield": "7.832%", "nav": "$0.307", "gearing": "0.00%", "assetType": "Infrastructure" }
, { "code": "CY6U", "descr": "Ascendas-iTrust", "prevClosed": "1.140", "period": "Q1 - Jun17", "dpu": "1.310", "ttlDpu": "5.240", "yield": "5.282%", "nav": "$0.810", "gearing": "0.00%", "assetType": "India - Industrial Park (7)" }
, { "code": "S7OU", "descr": "Asian Pay Tv Tr", "prevClosed": "0.605", "period": "Q2 - Jun17", "dpu": "1.625", "ttlDpu": "6.500", "yield": "16.883%", "nav": "$0.850", "gearing": "0.00%", "assetType": "Taiwan PayTV" }
, { "code": "ADQU", "descr": "Accordia Golf Tr", "prevClosed": "0.710", "period": "Q1 - Jun17", "dpu": "2.000", "ttlDpu": "6.220", "yield": "10.646%", "nav": "$0.890", "gearing": "0.00%", "assetType": "Japan Golf Courses - 89" }
, { "code": "BESU", "descr": "Indiabulls Trust", "prevClosed": "0.255", "period": "2H - Mar17", "dpu": "0.000", "ttlDpu": "0.064", "yield": "0.250%", "nav": "$1.273", "gearing": "0.00%", "assetType": "India - Office" }
, { "code": "NS8U", "descr": "HPH Trust USD", "prevClosed": "0.425", "period": "1H - Jun17", "dpu": "9.500", "ttlDpu": "3.34318", "yield": "9.578%", "nav": "HK$4.53", "gearing": "0.00%", "assetType": "Ports - HK (38%) + China (62%) by Revenue" }
, { "code": "RF1U", "descr": "RHT HealthTrust", "prevClosed": "0.895", "period": "2H - Jun17", "dpu": "2.370", "ttlDpu": "4.740", "yield": "8.045%", "nav": "$0.845", "gearing": "0.00%", "assetType": "India - Healthcare (18)" }
, { "code": "S6NU", "descr": "Croesus RTrust", "prevClosed": "1.165", "period": "2H - Jun17", "dpu": "4.060", "ttlDpu": "8.060", "yield": "8.503%", "nav": "Y76.63", "gearing": "0.00%", "assetType": "Japan - Retail (11)" }
, { "code": "CEDU", "descr": "Dasin Retail Tr", "prevClosed": "0.805", "period": "1H - Jun17", "dpu": "3.010", "ttlDpu": "6.020", "yield": "8.500%", "nav": "$1.490", "gearing": "0.00%", "assetType": "China - Retail" }
, { "code": "CJLU", "descr": "NetLink NBN Tr", "prevClosed": "0.825", "period": "FY18 - IPO", "dpu": "2.930", "ttlDpu": "4.400", "yield": "5.433%", "nav": "$0.864", "gearing": "0.00%", "assetType": "Fibre Network Infrastructure" }
];
