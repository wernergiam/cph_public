var transportDatas = [
{ "code": "S61", "descr": "SBSTransit", "prevClosed": "2.490", "period": "FY16 (Dec)", "dpu": "5.050", "ttlDpu": "5.050", "yield": "1.274%", "epsCts": "10.12", "pe": "39.19", "divBreakdown": "Interim 2.35ctct ; Final 2.70ct" }
, { "code": "C52", "descr": "ComfortDelGro", "prevClosed": "2.090", "period": "FY16 (Dec)", "dpu": "10.300", "ttlDpu": "10.300", "yield": "3.644%", "epsCts": "14.72", "pe": "17.56", "divBreakdown": "Interim 4.25ct ; Final 6.05ct" }
];
