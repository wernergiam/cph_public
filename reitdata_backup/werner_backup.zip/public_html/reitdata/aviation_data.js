var aviationDatas = [
{ "code": "S58", "descr": "SATS", "prevClosed": "4.960", "period": "FY17 (Mar)", "dpu": "17.000", "ttlDpu": "17.000", "yield": "3.093%", "epsCts": "23.20", "pe": "24.37", "divBreakdown": "Interim 6ct ; Final 11ct" }
, { "code": "S59", "descr": "SIA Engineering", "prevClosed": "3.230", "period": "FY17 (Mar)", "dpu": "18.000", "ttlDpu": "18.000", "yield": "4.154%", "epsCts": "29.63", "pe": "21.41", "divBreakdown": "Interim 4ct ; Final 9ct + Special 5ct" }
, { "code": "S63", "descr": "ST Engineering", "prevClosed": "3.300", "period": "FY16 (Dec)", "dpu": "15.000", "ttlDpu": "15.000", "yield": "4.644%", "epsCts": "15.60", "pe": "18.94", "divBreakdown": "Interim 5ct ; Final 10ct" }
];
