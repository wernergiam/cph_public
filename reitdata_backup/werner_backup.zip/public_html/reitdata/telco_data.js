var telcoDatas = [
{ "code": "Z74", "descr": "SingTel", "prevClosed": "3.690", "period": "FY17 (Mar)", "dpu": "17.500", "ttlDpu": "17.500", "yield": "4.795%", "epsCts": "23.96", "pe": "15.03", "divBreakdown": "Interim 6.8ct ; Final 10.7ct" }
, { "code": "B2F", "descr": "M1", "prevClosed": "1.790", "period": "FY16 (Dec)", "dpu": "12.900", "ttlDpu": "12.900", "yield": "7.806%", "epsCts": "16.10", "pe": "10.26", "divBreakdown": "Interim 7ct ; Final 5.9ct" }
, { "code": "CC3", "descr": "StarHub", "prevClosed": "2.830", "period": "FY16 (Dec)", "dpu": "20.000", "ttlDpu": "16.000", "yield": "7.117%", "epsCts": "19.80", "pe": "13.07", "divBreakdown": "Q1 5ct ; Q2 5ct ; Q3 5ct ; Q4 5ct" }
];
