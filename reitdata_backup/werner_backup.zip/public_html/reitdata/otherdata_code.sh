Kep Infra Tr|A7RU
Ascendas-iTrust|CY6U
Asian Pay Tv Tr|S7OU
Accordia Golf Tr|ADQU
Indiabulls Trust|BESU
HPH Trust USD|NS8U
RHT HealthTrust|RF1U
Croesus RTrust|S6NU
Dasin Retail Tr|CEDU
NetLink NBN Tr|CJLU