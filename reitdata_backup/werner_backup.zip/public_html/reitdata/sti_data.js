var stiDatas = [
{ "code": "S68", "descr": "SGX", "prevClosed": "7.540", "period": "FY17 (Jun)", "dpu": "28.000", "ttlDpu": "28.000", "yield": "3.911%", "epsCts": "31.70", "pe": "21.96", "divBreakdown": "Q1, Q2, Q3 5ct ; Q4 5ct +8ct" }
, { "code": "S08", "descr": "SingPost", "prevClosed": "1.280", "period": "FY17 (Mar)", "dpu": "3.500", "ttlDpu": "3.500", "yield": "4.778%", "epsCts": "8.50", "pe": "13.49", "divBreakdown": "Q1 = 1.5ct ; Q2 = 1ct ; Q3 = 0.5ct ; Q4 = 0.5ct" }
, { "code": "T39", "descr": "SPH", "prevClosed": "2.750", "period": "FY16 (Aug)", "dpu": "18.000", "ttlDpu": "18.000", "yield": "5.099%", "epsCts": "16.00", "pe": "22.06", "divBreakdown": "Interim 7ct ; Final 8ct + Special 3ct" }
];
