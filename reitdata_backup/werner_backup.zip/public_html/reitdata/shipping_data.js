var shippingDatas = [
{ "code": "D8DU", "descr": "FSL Trust", "prevClosed": "0.080", "period": "Q2 - Jun17", "dpu": "0.000", "ttlDpu": "0.000", "yield": "0.000%", "nav": "$0.390", "gearing": "44.20%", "assetType": "Shipping Trust" }
];
