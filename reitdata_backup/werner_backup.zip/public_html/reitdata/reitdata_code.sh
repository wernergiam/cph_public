AIMSAMP Cap Reit|O5RU
Ascendas Reit|A17U
Ascott Reit|A68U
BHG Retail Reit|BMGU
Cache Log Trust|K2LU
ESR-REIT|J91U
CapitaCom Trust|C61U
CapitaMall Trust|C38U
CapitaR China Tr|AU8U
EC World Reit|BWCU
First Reit|AW9U
Fortune Reit HKD|F25U
Frasers Com Tr|ND8U
Frasers Cpt Tr|J69U
Frasers L&I Tr|BUOU
Frasers L&I Tr AUD|BWQU
Indiabulls Trust|BESU
IREIT Global|UD1U
Keppel DC Reit|AJBU
Keppel Reit|K71U
Lippo Malls Tr|D5IU
ManulifeReit USD|BTOU
Mapletree Com Tr|N2IU
Mapletree GCC Tr|RW0U
Mapletree Ind Tr|ME8U
Mapletree Log Tr|M44U
OUE Com Reit|TS0U
ParkwayLife Reit|C2PU
Sabana Reit|M1GU
SoilbuildBizReit|SV3U
SPHREIT|SK6U
StarhillGbl Reit|P40U
Suntec Reit|T82U
Viva Ind Tr|T8B
Frasers HTrust|ACV
Far East HTrust|Q5T
OUE HTrust|SK7
Ascendas-hTrust|Q1P
CDL HTrust|J85