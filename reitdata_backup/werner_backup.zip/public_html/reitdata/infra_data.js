var infraDatas = [
{ "code": "AZI", "descr": "AusNetServices", "prevClosed": "1.920", "period": "2H - Mar17", "dpu": "A4.4", "ttlDpu": "9.52617", "yield": "5.428%", "nav": "A$0.82", "divBreakdown": "1H17 A4.4ct ; 2H17 A4.4ct" }
];
